
package REPASO_PRACTICA_3_TRIMESTRE.RepasoFicheros;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;

public class PlantillaEscritura {

    public static void main(String[] args) {
        
        String ruta = "src/ficheros/datos/EJ113.dat";
        BufferedWriter buferEscritor = null;
        
        try {
            buferEscritor = new BufferedWriter(new FileWriter(ruta));
        } catch (IOException e) {
            System.out.println("ERROR: problema escribiendo.");
            System.out.println(e.getMessage());
        } finally {
            try {
                if (buferEscritor != null) {
                    buferEscritor.close();
                }
            } catch (IOException e) {
                System.out.println("ERROR: problema cerrando.");
                System.out.println(e.getMessage());
            }
        }
    }
}
