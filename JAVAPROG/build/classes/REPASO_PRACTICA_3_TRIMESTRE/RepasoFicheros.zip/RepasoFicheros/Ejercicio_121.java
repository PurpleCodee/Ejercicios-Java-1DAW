package FICHERO;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.IOException;
import java.util.InputMismatchException;
//herramientas de escritura
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
//herramientas de lectura
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Set;

public class Ejercicio_121 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int opcion = 0;
        boolean salir = false;

        while (!salir) {
            /*-----------mensaje de principio-------------*/
            System.out.println("Padrón de Habitantes de Villanueva del Trabuco\n"
                    + "==============================================\n"
                    + "Elija una opción:\n"
                    + "1. Registrar habitante\n"
                    + "2. Mostrar padrón\n"
                    + "3. Salir \n");

            /*-------------------Eleccion del usuario--------------------*/
            do {
                System.out.print("¿Opción? >>");

                try {
                    opcion = teclado.nextInt();
                    
                    if (opcion == 4) {
                        System.out.println("Opcion no valida");

                    }

                } catch (InputMismatchException e) {
                    System.out.println(e.getMessage());

                }

            } while (opcion != 1 && opcion != 2 && opcion != 3);

            /*-------------------Acciones del programa---------------------*/
            switch (opcion) {
                /*------------------Registrar habitante-------------------------*/

                case 1:
                    System.out.print("Introduce DNI: ");
                    String dni = teclado.next();

                    System.out.print("Introduce tu Nombre: ");
                    String nombre = teclado.next();

                    System.out.print("Introduce tu Apellido: ");
                    String apellido = teclado.next();

                    System.out.print("Introduce tu Sexo: ");
                    String sexo = teclado.next();

                    int edad = 0;
                    boolean error = true;

                    do {
                        try {
                            System.out.print("Introduce tu edad: ");
                            edad = teclado.nextInt();
                            error = false;//la edad es correcta

                        } catch (InputMismatchException e) {
                            System.out.println(e.getMessage());
                            teclado.nextLine(); // Esto limpia el buffer de entrada
                            opcion = 0; // Resetear opcion para garantizar la repetición del bucle

                        }

                    } while (error);

                    Habitante personita = new Habitante(dni, nombre, apellido, edad, sexo);
                    System.out.println(personita);

                    String rutita = "src\\FICHERO\\datos\\DatosHabitante.txt";
                    FileWriter escritor = null;

                    BufferedWriter bufito = null;

                    BufferedReader bufitoLeer = null;
                    /*--------------------------Leemos con el buffer de lectura---------------------------------------*/
                    try {
                        bufitoLeer = new BufferedReader(new FileReader(rutita));
                        HashSet<String> habitantesExisten = new HashSet<>();
                        String datosPersona = "";

                        while ((datosPersona = bufitoLeer.readLine()) != null) {//no hacer de esta forma no gustar a jaime
                            if (!datosPersona.trim().isEmpty()) { // Asegúrate de que la línea no esté vacía
                                
                                String[]trozos = datosPersona.split(":");
                                
                                if (trozos.length > 1) {//verifico que almenos hay dos elementos
                                    habitantesExisten.add(trozos[1]);
                                    
                                }else{
                                    System.out.println("Datos incompletos");
                                }   
                            }
                        }
                        bufitoLeer.close();
                        /*----------------Verifico si el habitante existe---------------------------*/
                        if (habitantesExisten.contains(personita.getDNI())) {
                            System.out.println("El habitante ya esta registrado");

                        } else {
                            //si no existe registro al nuevo habitante
                            bufito = new BufferedWriter(new FileWriter(rutita, true));
                            bufito.write(personita.formatoHabitante());
                            bufito.newLine();//saltito de linea
                            bufito.close();
                            System.out.println("Nuevo habitante registrado correctamente");

                        }

                    } catch (FileNotFoundException e) {
                        System.out.println("Error: Fichero no encontrado");
                        System.out.println(e.getMessage());

                    } catch (IOException e) {
                        System.out.println("Error: No se han podido cerrar los "
                                + "flujos de datos o problema leyendo.");
                        System.out.println(e.getMessage());

                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("Te has pasado del rango del array");

                    } finally {

                        try {
                            if (bufito != null) {
                                bufito.close();
                            }
                            if (bufitoLeer != null) {
                                bufitoLeer.close();
                            }

                        } catch (IOException e) {
                            System.out.println("Error: Cerrando flujo de datos");
                            System.out.println(e.getMessage());
                        }
                    }

                    break;
                /*------------------Mostrar padron del habitante-------------------------*/
                case 2:
                    String ruta = "src\\FICHERO\\datos\\DatosHabitante.txt";
                    BufferedReader lector = null;

                    try {
                        lector = new BufferedReader(new FileReader(ruta));
                        String linea = "";
                        System.out.println("Listado de habitantes del padron: ");

                        while ((linea = lector.readLine()) != null) {
                            System.out.println(linea);

                        }

                    } catch (FileNotFoundException e) {
                        System.out.println("El archivo no fue encontrado: " + e.getMessage());

                    } catch (IOException e) {
                        System.out.println("Error al leer el archivo: " + e.getMessage());

                    } finally {
                        try {
                            if (lector != null) {
                                lector.close();

                            }

                        } catch (IOException e) {
                            System.out.println("Error al cerrar el archivo: " + e.getMessage());
                        }
                    }

                    break;
                /*------------------Terminar el programa-------------------------*/
                case 3:
                    System.out.println("Programa terminado enya eres la mejor te quiero");

                    salir = true;
                    break;
            }
        }
    }
}
