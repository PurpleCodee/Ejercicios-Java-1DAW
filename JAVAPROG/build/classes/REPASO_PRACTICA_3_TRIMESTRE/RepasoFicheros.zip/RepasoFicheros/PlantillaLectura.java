package REPASO_PRACTICA_3_TRIMESTRE.RepasoFicheros;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class PlantillaLectura {

    public static void main(String[] args) {

        String ruta = "src/ficheros/datos/algo.txt";

        FileReader lector = null;
        BufferedReader buf = null;
        /*-----------ESTRUCTURA DE PLANTILLA DE LECTURA-----------------*/
        try {
            buf = new BufferedReader(new FileReader(ruta));
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: fichero no encontrado.");
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println("ERROR: no se han podido cerrar los flujos de dato O problema leyendo.");
            System.out.println(e.getMessage());
        } finally {
            try {
                if (buf != null) {
                    buf.close();
                }

                if (lector != null) {
                    lector.close();
                }

            } catch (IOException e) {
                System.out.println("Error: problema cerrando flujo de datos.");
            }
        }

        /*-----------------COMO LEER CARACTER A CARACTER-----------------------*/
        int misterio = 0;
        try {
            do {
                misterio = buf.read();//solo read porque leo una linea
                if (misterio != -1) {
                    System.out.println((char) misterio);
                }
            } while (misterio != -1);

        } catch (FileNotFoundException e) {
            System.out.println("ERROR: fichero no encontrado.");
            System.out.println(e.getMessage());

        } catch (IOException e) {
            System.out.println("ERROR: no se han podido cerrar los flujos de dato O problema leyendo.");
            System.out.println(e.getMessage());

        }
        /*-----------------COMO LEER LINEA A LINEA-----------------------*/
        String texto = "";
        boolean salir = false;
        String listaTexto[] = new String[3];
        try {
              while (!salir) {
                texto = buf.readLine();

                if (texto != null) {
                    salir = true;

                } else {
                    
                    listaTexto = texto.split(":");

                    System.out.println("Item: " + "\t\t" + listaTexto[0]);
                    System.out.println("Precio: " + "\t" + listaTexto[1]);
                    System.out.println("Cantidad: " + "\t" + listaTexto[2] + "\n");

                }

            }
           

        } catch (FileNotFoundException e) {
            System.out.println("ERROR: fichero no encontrado.");
            System.out.println(e.getMessage());
            
        }catch (IOException e) {
            System.out.println("ERROR: no se han podido cerrar los flujos de dato O problema leyendo.");
            System.out.println(e.getMessage());

        }
    }
}
