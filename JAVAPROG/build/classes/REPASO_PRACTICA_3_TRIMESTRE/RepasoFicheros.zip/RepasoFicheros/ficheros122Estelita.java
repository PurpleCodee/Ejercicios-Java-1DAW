package REPASO_PRACTICA_3_TRIMESTRE.RepasoFicheros;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;

public class ficheros122Estelita {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        boolean terminar = false;
        BufferedWriter escritor = null;
        BufferedReader lector = null;
        String ruta = "";
        String angelito[][] = new String[4][2]; // Voy a guardar los datos del jugador
        int i = 0;
        String luis = "";
        boolean lleno = false;
        String horses = "src/ficheros/datos/horses.txt";
        String gyro = "";
        boolean terminado = false;
        String uma[][] = new String[3][2]; // Voy a guardar los caballos
        int j = 0;
        int k = 0;
        int l = 0;

        do {

            // a) Mensaje de bienvenida con el nombre del juego
            System.out.println("Welcome to Hol Horse Alone!!");
            System.out.println("----------------------------");

            // b)Se pide el nombre del jugador
            System.out.print("Insert name: ");
            String playerName = teclado.nextLine();

            try {
                // c) Buscar el archivo 'nombre del jugador'.dat
                //Si existe, usa los datos de ese fichero
                ruta = "src/ficheros/datos/" + playerName + ".txt";

                lector = new BufferedReader(new FileReader(ruta));
                //El buffered reader sirve para acceder al archivo y leer las lineas.

                while (!lleno) {//mientras que este lleno
                    luis = lector.readLine();
                    if (luis == null) {
                        lleno = true; //recuerda que esto no es un return, por lo que no se va a cortar ahi el codigo.
                    } else { //por ello se necesita un else.
                        angelito[i] = luis.split(":");
                        // d) Saca por pantalla los datos
                        System.out.println(angelito[i][0] + ": " + angelito[i][1]);
                        i += 1;
                    }
                }

            } catch (FileNotFoundException e) {
                System.out.println("El fichero no se ha encontrado.");
                System.out.println("Creando uno nuevo...");

                try {
                    escritor = new BufferedWriter(new FileWriter(ruta));
                    //El bufferedWriter sirve para escribir, acceder al archivo Y CREARLO si no existiese 

                    //Si no existe se crea con valores predeterminados
                    escritor.write("nombre:" + playerName + System.lineSeparator());
                    escritor.write("dinero:100" + System.lineSeparator());
                    escritor.write("aput:0" + System.lineSeparator()); //apuetas totales
                    escritor.write("apug:0" + System.lineSeparator()); //apuestas ganadas

                } catch (IOException f) {
                    System.out.println("ERROR: problema escribiendo.");
                    System.out.println(f.getMessage());
                } finally {

                    try {
                        if (escritor != null) {
                            escritor.close();
                        }

                    } catch (IOException g) {
                        System.out.println("ERROR: no se han podido cerrar los flujos de dato o problema escribiendo.");
                        System.out.println(g.getMessage());
                    }
                }

            } catch (IOException e) {
                System.out.println("ERROR: no se han podido cerrar los flujos de dato o problema leyendo.");
                System.out.println(e.getMessage());
            }

            // e) Cargar el archivo horses.dat y leer su contenido
            // Si el archivo no existe, dará error. -> sout: las carreras no pueden realizarse porque no hay caballos.
            try {
                lector = new BufferedReader(new FileReader(horses));

                while (!terminado) {//mientras no haya terminado
                    gyro = lector.readLine(); // El lector.read lee caracter por caracter

                    if (gyro == null) {
                        terminado = true;//si gyro termina de leer hay terminado
                    } else {
                        uma[j] = gyro.split(":");
                        j += 1;//esto es el inclemento del while
                    }
                }

            } catch (IOException h) {
                System.out.println("ERROR: no se han podido cerrar los flujos de dato o problema leyendo.");
                System.out.println(h.getMessage());
            }

            //Zona de la carrera
            System.out.println(System.lineSeparator() + "---------------------");
            System.out.println("Zona de la carrera...");
            System.out.println("---------------------" + System.lineSeparator());

            do {
                System.out.println(System.lineSeparator() + "-----------------------------");
                System.out.println("Caballos por los que apostar:");
                System.out.println("-----------------------------");

                System.out.println("1.- " + uma[0][0] + ":" + uma[0][1]);
                System.out.println("2.- " + uma[1][0] + ":" + uma[1][1]);
                System.out.println("3.- " + uma[2][0] + ":" + uma[2][1] + System.lineSeparator());

                System.out.print("¿Quiere apostar por alguno? (Si/No): ");
                String respuesta = teclado.next();

                if (respuesta.toLowerCase().equals("no")) {
                    terminar = true;
                }

                System.out.print(System.lineSeparator() + "Elija cual: ");
                int numCaballo = teclado.nextInt();

                switch (numCaballo) {
                    case 1:
                        System.out.println("Ha elegido apostar por " + uma[0][0]);
                        break;
                    case 2:
                        System.out.println("Ha elegido apostar por " + uma[1][0]);
                        break;
                    case 3:
                        System.out.println("Ha elegido apostar por " + uma[2][0]);
                        break;
                    default:
                        System.out.println("No es una opción válida");
                }

                System.out.print(System.lineSeparator() + "¿Cuánto desea apostar? (mayor de 15€): ");
                int apuesta = teclado.nextInt();

                if (apuesta < 15) {
                    System.out.println("Solo apuestas por encima de 15€.");
                    System.out.println("Sin dinero no hay apuesta.");
                    terminar = true;//el while termina si la apuesta es menor que 15
                } else {
                    System.out.println("Se va a realizar la apuesta con " + apuesta + " euros...");
                }

                String confirmacion = "";
                boolean cerrarApuesta = false;

                do {
                    System.out.print(System.lineSeparator() + "¿Quiere hacer la apuesta con " + apuesta + " euros? (Si/No): ");
                    confirmacion = teclado.next();

                    if (confirmacion.toLowerCase().equals("no")) {
                        System.out.print(System.lineSeparator() + "¿Cuánto desea apostar? (mayor de 15€): ");
                        apuesta = teclado.nextInt();
                        
                        System.out.println("La apuesta se hará con " + apuesta + " euros.");
                    } else if (confirmacion.toLowerCase().equals("si")) {
                        cerrarApuesta = true;
                    }
                } while (!cerrarApuesta);//se ejecuta mientras siga apostando

                System.out.println(System.lineSeparator() + "Inicia la carrera!!" + System.lineSeparator());

                int caballoGanador = (int) (Math.random() * (3 + 1));

                switch (caballoGanador) {
                    case 1:
                        System.out.println("Y el caballo ganador es... " + uma[0][0] + "!!" + System.lineSeparator());
                        uma[0][1] = String.valueOf(Integer.parseInt(uma[0][1]) + 1);
                        break;
                    case 2:
                        System.out.println("Y el caballo ganador es... " + uma[1][0] + "!!" + System.lineSeparator());
                        uma[1][1] = String.valueOf(Integer.parseInt(uma[1][1]) + 1);
                        break;
                    case 3:
                        System.out.println("Y el caballo ganador es... " + uma[2][0] + "!!" + System.lineSeparator());
                        uma[2][1] = String.valueOf(Integer.parseInt(uma[2][1]) + 1);
                        break;
                }

                angelito[2][1] = String.valueOf(Integer.parseInt(angelito[2][1]) + 1); //actualizo las apuestas totales

                if (numCaballo == caballoGanador) {
                    System.out.println("Apuesta ganada!!");
                    angelito[1][1] = String.valueOf(Integer.parseInt(angelito[1][1]) + (apuesta * 150) / 100); //actualiza dinero
                    angelito[3][1] = String.valueOf(Integer.parseInt(angelito[3][1]) + 1); //actualizo las apuestas ganadas

                } else {
                    System.out.println("Lo siento, perdiste... no apuestes");
                    angelito[1][1] = String.valueOf(Integer.parseInt(angelito[1][1]) - apuesta); //actualiza dinero
                }

                System.out.println(System.lineSeparator() + "Dinero actual: " + angelito[1][1] + System.lineSeparator());

                System.out.print("¿Quiere seguir apostando? (Si/No): ");
                String respuestaFinal = teclado.next();

                if (respuestaFinal.toLowerCase().equals("no")) {
                    terminar = true;
                    System.out.println(System.lineSeparator() + "See you again!");
                } else {
                    terminar = false;
                }

            } while (Integer.parseInt(angelito[1][1]) > 15 && !terminar);

            terminar = true;

        } while (!terminar);

        try {

            escritor = new BufferedWriter(new FileWriter(ruta));

            while (k < angelito.length) {
                escritor.write(angelito[k][0] + ":" + angelito[k][1]);
                k += 1;
            }
            escritor.close();

            escritor = new BufferedWriter(new FileWriter(ruta));

            while (l < uma.length) {
                escritor.write(uma[l][0] + ":" + uma[l][1]);
                l += 1;
            }

        } catch (IOException e) {
            System.out.println("ERROR: no se han podido cerrar los flujos de dato o problema leyendo.");
            System.out.println(e.getMessage());
        } finally {
            try {
                if (escritor != null) {
                    escritor.close();
                }

            } catch (IOException e) {
                System.out.println("ERROR: no se han podido cerrar los flujos de dato o problema leyendo.");
                System.out.println(e.getMessage());
            }

        }

    }
}
