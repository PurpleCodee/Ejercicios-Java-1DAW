
package FICHERO;
public class Habitante {
    private String DNI;
    private String nombre;
    private String apellido;
    private int edad;
    private String sexo;

    public Habitante(String DNI, String nombre, String apellido, int edad, String sexo) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.sexo = sexo;
    }
    public String formatoHabitante(){
        return "DNI: " + this.DNI + "\n" 
               +"nombre: " + this.nombre + "\n"
               +"apellido: " + this.apellido +"\n" 
               +"edad: " + this.edad + "\n"
               +"sexo: " + this.sexo + "\n";
    
    }

    public String getDNI() {
        return DNI;
    }
    

    @Override
    public String toString() {
        return "-------------\n"
                + "Habitante"+"\n"
                + "----------------"+"\n"
                + "Nombre------->"+ this.nombre+"\n"
                + "Apellido------->" + this.apellido+"\n"
                + "Edad------->" + this.edad+"\n"
                + "Sexo------->"+ this.sexo+"\n";
    } 
    
}
